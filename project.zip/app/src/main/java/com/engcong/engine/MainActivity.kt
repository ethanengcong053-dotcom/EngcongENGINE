package com.engcong.engine

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.View
import android.view.ViewGroup.LayoutParams.MATCH_PARENT
import android.view.ViewGroup.LayoutParams.WRAP_CONTENT
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import com.google.mediapipe.tasksgenai.llminference.LlmInference
import java.io.File
import java.io.FileOutputStream

class MainActivity : Activity() {

    private val bg = Color.parseColor("#10282B")
    private val panel = Color.parseColor("#173A3E")
    private val textColor = Color.parseColor("#E8F1EE")
    private val dim = Color.parseColor("#93B0AA")
    private val brass = Color.parseColor("#D9A441")

    private val pickCode = 42
    private val ui = Handler(Looper.getMainLooper())
    private val history = ArrayList<Pair<String, String>>()

    private var llm: LlmInference? = null
    private var busy = false

    private lateinit var status: TextView
    private lateinit var pick: Button
    private lateinit var scroll: ScrollView
    private lateinit var log: LinearLayout
    private lateinit var input: EditText
    private lateinit var sendBtn: Button

    private fun dp(n: Int): Int = (n * resources.displayMetrics.density).toInt()
    private fun modelFile(): File = File(filesDir, "model.task")

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(bg)
            fitsSystemWindows = true
        }
        val title = TextView(this).apply {
            text = "EngcongEngine"
            textSize = 22f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(textColor)
            setPadding(dp(16), dp(12), dp(16), 0)
        }
        status = TextView(this).apply {
            textSize = 13f
            setTextColor(dim)
            setPadding(dp(16), dp(2), dp(16), dp(8))
        }
        pick = Button(this).apply {
            text = "Choose model file"
            setOnClickListener { pickModel() }
        }
        scroll = ScrollView(this)
        log = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(12), dp(8), dp(12), dp(8))
        }
        scroll.addView(log)

        val bar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(dp(8), dp(8), dp(8), dp(8))
        }
        input = EditText(this).apply {
            hint = "Ask something"
            setTextColor(textColor)
            setHintTextColor(dim)
            maxLines = 4
            isEnabled = false
        }
        sendBtn = Button(this).apply {
            text = "Send"
            isEnabled = false
            setOnClickListener { send() }
        }
        bar.addView(input, LinearLayout.LayoutParams(0, WRAP_CONTENT, 1f))
        bar.addView(sendBtn)

        root.addView(title)
        root.addView(status)
        root.addView(pick)
        root.addView(scroll, LinearLayout.LayoutParams(MATCH_PARENT, 0, 1f))
        root.addView(bar)
        setContentView(root)

        if (modelFile().exists()) {
            loadModel()
        } else {
            status.text = "Choose a model file to start. You only do this once."
        }
    }

    private fun addBubble(msg: String, mine: Boolean): TextView {
        val tv = TextView(this).apply {
            text = msg
            textSize = 16f
            setTextColor(if (mine) bg else textColor)
            setPadding(dp(14), dp(10), dp(14), dp(10))
            background = GradientDrawable().apply {
                cornerRadius = dp(14).toFloat()
                setColor(if (mine) brass else panel)
            }
            setTextIsSelectable(true)
        }
        val lp = LinearLayout.LayoutParams(WRAP_CONTENT, WRAP_CONTENT).apply {
            gravity = if (mine) Gravity.END else Gravity.START
            topMargin = dp(6)
            bottomMargin = dp(6)
            if (mine) marginStart = dp(48) else marginEnd = dp(48)
        }
        log.addView(tv, lp)
        scroll.post { scroll.fullScroll(View.FOCUS_DOWN) }
        return tv
    }

    private fun pickModel() {
        val i = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "*/*"
        }
        startActivityForResult(i, pickCode)
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == pickCode && resultCode == RESULT_OK) {
            data?.data?.let { copyModel(it) }
        }
    }

    private fun copyModel(uri: Uri) {
        pick.isEnabled = false
        status.text = "Copying model…"
        Thread {
            val tmp = File(filesDir, "model.tmp")
            try {
                contentResolver.openInputStream(uri)!!.use { inp ->
                    FileOutputStream(tmp).use { out ->
                        val buf = ByteArray(1 shl 20)
                        var total = 0L
                        var last = 0L
                        while (true) {
                            val n = inp.read(buf)
                            if (n < 0) break
                            out.write(buf, 0, n)
                            total += n
                            if (total - last > 25L * 1024 * 1024) {
                                last = total
                                val mb = total shr 20
                                ui.post { status.text = "Copying model… $mb MB" }
                            }
                        }
                    }
                }
                tmp.renameTo(modelFile())
                ui.post {
                    pick.isEnabled = true
                    loadModel()
                }
            } catch (e: Exception) {
                tmp.delete()
                ui.post {
                    pick.isEnabled = true
                    status.text = "Could not copy the model: ${e.message}"
                }
            }
        }.start()
    }

    private fun loadModel() {
        status.text = "Loading model…"
        pick.visibility = View.GONE
        Thread {
            try {
                val opts = LlmInference.LlmInferenceOptions.builder()
                    .setModelPath(modelFile().absolutePath)
                    .setMaxTokens(2048)
                    .build()
                llm = LlmInference.createFromOptions(this@MainActivity, opts)
                ui.post {
                    status.text = "Ready. Running offline on this phone."
                    input.isEnabled = true
                    sendBtn.isEnabled = true
                    if (log.childCount == 0) {
                        addBubble("Hi, I’m EngcongEngine. I run on this phone, so nothing leaves it. Ask me anything.", false)
                    }
                }
            } catch (e: Exception) {
                ui.post {
                    status.text = "Could not load the model: ${e.message}"
                    pick.visibility = View.VISIBLE
                }
            }
        }.start()
    }

    private fun buildPrompt(): String {
        val sb = StringBuilder()
        for ((role, t) in history.takeLast(7)) {
            sb.append("<start_of_turn>").append(role).append("\n")
                .append(t).append("<end_of_turn>\n")
        }
        sb.append("<start_of_turn>model\n")
        return sb.toString()
    }

    private fun send() {
        val q = input.text.toString().trim()
        val engine = llm
        if (q.isEmpty() || engine == null || busy) return
        input.setText("")
        busy = true
        sendBtn.isEnabled = false
        addBubble(q, true)
        history.add("user" to q)
        val out = addBubble("Thinking…", false)
        val prompt = buildPrompt()
        Thread {
            val reply = try {
                engine.generateResponse(prompt).trim()
            } catch (e: Exception) {
                "Error: ${e.message}"
            }
            ui.post {
                out.text = reply
                history.add("model" to reply)
                busy = false
                sendBtn.isEnabled = true
            }
        }.start()
    }
}
